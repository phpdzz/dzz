<?php
namespace api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;

/**
 * Site controller
 */
class ExamController extends Controller
{
    /**
     * @inheritdoc
     */ 
    public $enableCsrfValidation = false;
    public function actionImport()
    {
    	$data = $_FILES['excel'];
    	// var_dump($data);exit();
    	$title = Yii::$app->request->post('title');
    	$dir = "/phpstudy/www/yiinew/api/upload/excel.xls";
    	$reg = move_uploaded_file($data['tmp_name'], $dir);
    	// var_dump($reg);die;
    	require(__DIR__ . '/../../common/libs/PHPExcel.php');
    	$excel = new \PHPExcel();
        // header("content-type:text/html;charset=utf-8");
    	$objPHPExcel = \PHPExcel_IOFactory::load($dir);

    	$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
    	unset($sheetData[1]);
    	// var_dump($sheetData);exit();

    	foreach ($sheetData as $key => $v)
    	{
    		if ($v['B'] == "1-单选")
	    	{
	    		$num = '3';
	    	}else{
	    		$num = '2';
	    	}

	    	$dzz = array(
	    		'unti'=>$v['C'],
	    		'unit'=>$title,
	    		'type'=>$v['B'],
	    		'num'=>$num,
	    		'addtime'=>time()
	    	);

            // $sql = 'insert into topic(unti,unit,type,num,addtime) values("'.$v['C'].'","'.$title.'","'.$v['B'].'","'.$num.'","'.time().'")';
            // echo $sql;die;
            //添加题目表
	    	$data = Yii::$app->db->createcommand()->insert('topic',$dzz)->execute();
            // var_dump($data);
            if ($data)
            {
                $id = Yii::$app->db->getlastInsertID();
                // echo $id."</br>";

                $ya = array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

                $yes = str_split($v['J'],1);
                // var_dump($yes);
                for ($i='D'; $i < 'I'; $i++)
                { 
                    if (!empty($v[$i]))
                    {
                        $is = in_array($ya[$i], $yes) ? 1 : 0;
                        $qzz = array(
                            'topic_id'=>$id,
                            'answer'=>$v[$i],
                            'yes_no'=>$is
                        );
                        // var_dump($v[$i]);
                        $data = Yii::$app->db->createcommand()->insert('answer',$qzz)->execute();
                    }
                }

            }
            
    	}
    	
        echo "<script>alert('入库完成!')</script>";
        // $url = '';
        // header('location:'.$url);
        $this->show();
    }


    public function show()
    {
        $url= 'http://59.110.169.29/yiinew/backend/web/index.php?r=exam/show';
        header("location:".$url);
    }


}



?>