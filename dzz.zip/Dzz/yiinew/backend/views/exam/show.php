<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
</head>
<body>
<form action="index.php?r=exam/score" method="post">
<table class="table table-striped">
	<div style="width: 100%;height: 80px;background-color: #7896F3;">
		<img src="http://pic37.photophoto.cn/20151204/0020033043921779_b.jpg" style="width: 80px;height: 80px;"><font style="font-size: 25px;color: #000000;font-family: 黑体;padding-left: 10px;">八维考试系统</font>
	</div>
<?php foreach ($data as $key => $v): ?>
	<?php if ($v['type'] == '1-单选'){?>
		<thead>
			<tr>
				<th style="font-size: 16px;color: #A79F9F;"><?=$v['unit'] ?></th>
			</tr>
			<tr>
				<th><img src="https://i01picsos.sogoucdn.com/5161b542d43af3b4" style="width: 30px;height: 30px;">1-单选题:</th>
			</tr>
		</thead>
	<?php }elseif ($v['type'] == '2-多选'){?>
		<thead>
			<tr>
				<th style="font-size: 16px;color: #A79F9F;"><?=$v['unit'] ?></th>
			</tr>
			<tr>
				<th><img src="https://i01picsos.sogoucdn.com/5161b542d43af3b4" style="width: 30px;height: 30px;">2-多选题:</th>
			</tr>
		</thead>
	<?php }else{ ?>
		<thead>
			<tr>
				<th style="font-size: 16px;color: #A79F9F;"><?=$v['unit'] ?></th>
			</tr>
			<tr>
				<th><img src="https://i01picsos.sogoucdn.com/5161b542d43af3b4" style="width: 30px;height: 30px;">0-判断题:</th>
			</tr>
		</thead>
	<?php } ?>
	<tbody>
	<tr>
	<td id="<?=$v['topic_id'] ?>"><?=$key+1 ?>、<?=$v['unti'] ?>(		);</td>
	</tr>
	<?php $n = "A" ?>
	<?php foreach ($answer as $k => $val): ?>
		<?php if ($val['topic_id'] == $v['topic_id']) { ?>
			<?php if ($v['type'] == '1-单选' || $v['type'] == '0-判断'){ ?>
					<tr>
						<td>
							<label class="radio-inline">
								<input type="radio" name="<?=$key ?>">
									<?=$n; ?>:<?=$val['answer'] ?>
									<?php $n++; ?>
							</label>
						</td>
					</tr>
			<?php }else{?>
				<tr>
				<td>
					<label class="checkbox-inline">
						<input type="checkbox" id="inlineCheckbox3"><?=$n; ?>:<?=$val['answer'] ?>
						<?php $n++; ?>
					</label></td>
				</tr>
			<?php } ?>
		<?php } ?>
	<?php endforeach ?>
<?php endforeach ?>
</tbody>
</table>
<input type="submit" name="" value="提交" class="btn btn-default btn-lg active" style="width: 100px;font-family: 楷体;margin-top: 30px;margin-left: 20px;">
</form>
</body>
</html>