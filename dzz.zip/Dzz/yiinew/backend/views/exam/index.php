<form role="form" method="post" enctype="multipart/form-data" action="index.php?r=exam/add">
<div class="form-group">
<label for="name">名称</label>
<input type="text" class="form-control" id="name" placeholder="请输入名称" name="name">
</div>
<div class="form-group">
<label for="inputfile">文件输入</label>
<input type="file" id="inputfile" name="paper">
<p class="help-block">这里是块级帮助文本的实例。</p>
</div>
<div class="checkbox">
<label>
<input type="checkbox">请打勾
</label>
</div>
<button type="submit" class="btn btn-default">提交</button>
</form>