<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use common\libs\curl;

/**
 * Site controller
 */
class ExamController extends Controller
{
    /**
     * @inheritdoc
     */ 
    public $enableCsrfValidation = false;
    public function actionIndex()
    {
    	return $this->render('index');
    }

    public function actionAdd()
    {
    	// curl::_get('suibian');
    	
    	if (Yii::$app->request->isPost)
    	{
    		$data = $_FILES["paper"];
    		// var_dump($data);exit();
    		$dir = "/phpstudy/www/yiinew/backend/upload/excel.xls";

    		$reg = move_uploaded_file($data['tmp_name'], $dir);

    		// var_dump($reg);die;
    		if ($reg)
    		{
    			$url= 'http://59.110.169.29/yiinew/api/web/index.php?r=exam/import';
    			$param['title'] = Yii::$app->request->post('name');
    			// var_dump($param);die;
    			$file['excel'] = $dir;

    			$reg = curl::_post($url, $param, $file);
    			if ($reg)
    			{
    				echo $reg;exit();
    			}
    			
    		}

    	}else{
    		return $this->render('add');
    	}
    }


    public function actionShow()
    {
    	
       	
         $sql0 = "select * from topic WHERE type='1-单选' order by RAND() limit 20";
         $sql1 = "select * from topic WHERE type='2-多选' order by RAND() limit 10";
         $sql2 = "select * from topic WHERE type='0-判断' order by RAND() limit 10";
         $sql3 = 'select * from answer';

         $data0 = Yii::$app->db->createCommand($sql0)->queryAll();
         $data1 = Yii::$app->db->createCommand($sql1)->queryAll();
         $data2 = Yii::$app->db->createCommand($sql2)->queryAll();
         $data3 = Yii::$app->db->createCommand($sql3)->queryAll();
         // var_dump($data0);
         // var_dump($data1);
         // var_dump($data2);

         $data = array_merge($data0,$data1,$data2);
         // var_dump($abcd);die;
        return $this->render('show',['data'=>$data,'answer'=>$data3]);
    }



    public function actionScore()
    {
    	echo "67";
    }
}




?>